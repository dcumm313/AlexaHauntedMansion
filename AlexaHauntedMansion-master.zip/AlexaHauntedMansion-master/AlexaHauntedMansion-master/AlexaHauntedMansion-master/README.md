# AlexaMystery
An Alexa mystery game for the Amazon July 2017 Alexa Developer's Campaign. Adapted from Amazon’s Decision Tree example.
