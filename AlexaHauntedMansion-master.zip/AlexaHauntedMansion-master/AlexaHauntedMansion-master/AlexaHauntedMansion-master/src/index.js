/**
 * Haunted Mansion Game by Dillon Cummings
 *
 * This skill adapted from Amazon's skill-sample-nodejs-decision-tree master branch on GitHub
 *
 * The skill has been altered significantly to implement an escape game
 * The user must escape the house by investigating and interacting with rooms
 */

var Alexa = require('alexa-sdk');

var states = {
    STARTMODE: '_STARTMODE',                // Prompt the user to start the game.
    ASKMODE: '_ASKMODE',                    // Alexa is asking user what they would like to do, describing rooms and interactions
    ACCUSEMODE: '_ACCUSEMODE'          // Alexa is asking user to accuse which person they think did it
};


// All items the user can pick up in the game
var items =[
    // Plank to unlock main entrance -> grand staircase
    { "itemId": 0, "names": ["plank", "board", "bored", "bridge", "wood", "wooden plank"], 
      "description": "A wooden plank, that seems like it could support your weight. Definitely could come in handy!", "found": false, "useRoom": 3},
	// Chew Toy to befriend dog-> Exit
    { "itemId": 1, "names": ["chew toy", "stuffed duck", "duck", "toy", "dog toy", "duct"], 
      "description": "A chew toy in the form of a stuffed duck, that was fondly played with judging by it's scars and exposed stuffing. What happened to the dog that owned it though?", "found": false, "useRoom": 4},
	// Key to unlock brother's room -> brother's room
    { "itemId": 2, "names": ["keys", "key ring", "key", "mansion keys", "mansion's keys"], 
      "description": "A brass key, found in the parent's room.", "found": false, "useRoom": 5},
	// Magic skull to unlock secret passage -> basement
	  { "itemId": 3, "names": ["magic skull", "old skull", "skull", "shkull", "magic head"], 
      "description": "A creepy skull with glowing green eye holes. A beam shines out from them, as if trying to illuminate something.", "found": false, "useRoom": 6},
	  ];

// All of the rooms that the user can enter in the game
var rooms = [{ "names": ["main hallway", "main entrance", "entrance", "corridor", "main corridor"], "roomId": 0, "neighbors": [1,2,3], "unlockItemId": -1, "visited": true,
                "roomDesc": "The entrance to the house is as large and palatial as the exterior, and equally decrepit. Roaches skitter away as you walk on the dirty marble tile, and the house groans in response to your presence.", 
                "interactables": []}, // End Main Hallway room
              { "names": ["dining room", "dining hall", "dinner room", "principals room", "principals", "main office"], "roomId": 1, "neighbors": [0,4], "unlockItemId": -1, "visited": false,
                "roomDesc": "The dining room boast a rotting scent, from the plates of food left over after the Goings abandoned their home. The showy cabinets of china and silverware are now covered in dust, grime, and a forest of cobwebs. A suspicious napkin is crumpled by the floor. The walk-in pantry is left open.", 
                "interactables": [{ "names": ["napkin", "crumpled napkin", "cloth"], "take": false,
                                    "description": "A crumpled napkin lies conspicuously on the floor, it is monogramed GG, and seems to have strange, mystical writing scribbled on it." }
                ]}, // End dining room
				{ "names": ["library", "book room", "personal library", "the library"], "roomId": 2, "neighbors": [0], "unlockItemId": -1, "visited": false,
                "roomDesc": "The library is filled with ancient books, now covered in dust and home to all manner of foul insects that feast on the pages. The wall is filled with university degrees and certifications hung with pride, though they now look too grimy and torn to even recognize the writing.", 
                "interactables": [{ "names": ["bookshelf", "books", "book", "shelf", "bookshelves"], "take": false,
                                    "description": "Bookshelves line the room, filled in every inch by ancient tombs and dusty manuscripts. You see a suspicious open space in the occult section of the library, meaning one of the books was taken." },
                                  { "names": ["desk notes", "library notes", "librarian notes", "notes", "note"], "take": false,
                                    "description": "A note written by the mother of the house, she complains about the butler and maid, saying that they seem rather shifty nowadays. She has noticed one of her expensive books missing, and is sure one of them must have pilfered it." }
                ]}, // End library room
              { "names": ["pantry", "food closet", "pantry closet", "walk-in pantry"], "roomId": 4, "neighbors": [1], "unlockItemId": -1, "visited": false,
                "roomDesc": "In this walk-in closet, you see various sanitary liquids, open boxes of food, and sealed cans of preserves.", 
                "interactables": [{ "names": ["journal", "diary", "butlers journal", "butlers diary", "butlers notes", "notes"], "take": false,
                                    "description": "The butler's journal is on a shelf in the closet. On the most recent page you read: The greedy master of the house is too concerned with local politics to focus on the strange things his family are up to." },
                                  { "names": ["plank", "board", "bridge", "wood", "wooden plank"], "take": true, "itemId": 0,
                                    "description": "A wooden plank lies against the wall, probably a fallen divider that might have been accidentally ripped out by someone with monstrous strength. It seems light enough to carry, but heavy enough to support your weight." }
                ]}, // End pantry room
              { "names": ["grand staircase", "staircase", "stairs", "grand stairs"], "roomId": 3, "neighbors": [0,5,7], "unlockItemId": 0, "visited": false, 
                "lockMsg": "The hole in the staircase is far too wide to jump, if only you had some sort of bridge you could certainly cross it.", "unlockMsg": "You carefully lay the wooden plank down at the edge of the stair gap, and after testing to make sure it will hold you, gently walk up the new ramp.",
                "roomDesc": "The staircase is as ornate as the rest of the mansion, and in just as much disrepair. You aren't certain the railings will even hold you, so you don't test them. In front of you is the rubble of a doorway, there's no way you can enter from where you are. But to your right is what looks like the parent's room, doors wide open. To your left is a dark hallway leading to the daughter's room. Where would you like to go?", 
                "interactables": [ { "names": ["chew toy", "stuffed duck", "duck", "toy", "dog toy", "duct"], "take": true, "itemId": 1,
                                    "description": "You hear a squeak by your foot. A chew toy in the shape of a duck lies on the floor by the railing, it's stuffing partially coming out. It looks like it was a favorite toy of the dog of the house. Maybe it's good luck?" }
				]}, // End grand staircase room
			  { "names": ["Parent's room", "parent room", "dad's room", "mom's room", "father's room", "mother's room"], "roomId": 5, "neighbors": [4,9], "unlockItemId": -1, "visited": false,
                "roomDesc": "The desolate bedroom of the parent's of the house boasts a moth eaten bed, a dark cracked mirror, and an empty bowl of food for the family pet. Spider's have claimed the room as their lair, you can't walk two steps without brushing off a cobweb. The adjoining walk-in closet is open.", 
                "interactables": [{ "names": ["keys", "key ring", "key", "mansion keys", "mansion's keys"], "take": true, "itemId": 2,
                                    "description": "You see a ring of keys on the nightstand by the bed. These might be your key out of here! Or at least a door somewhere around this rotting corpse of a house." },
								  { "names": ["picture", "pic", "portrait", "picture frame"], "take": false,
                                    "description": "A framed picture is hung on the wall, it depicts the whole family, including the maid and butler posing in front of the mansion. Everyone is smiling, except the maid and the daughter. The maid seems to be gripping the duaghter's shoulder very hard."}
								 ]}, // End parent's room
			  { "names": ["closet", "parent closet", "dad's closet", "mom's closet", "father's closet", "mother's closet"], "roomId": 9, "neighbors": [5,6], "unlockItemId": -1, "visited": false,
                "roomDesc": "You pull the cord in front of your face, and have a large walk in closet revealed to you. Mothballs cover every suit and dress, with strange rattling coming from one of the closets you'd rather not examine. There seems to be another door at the end of the closet, it's locked, but it looks like it leads to the blocked son's room!", 
                "interactables": [{ "names": ["will", "will and testament", "inheritance", "will paper", "will sheet"], "take": false,
                                    "description": "You see hidden in one of the drawers an official looking paper. At the top it reads The Last Will and Testament of William Goings. In it he leaves the family estate to his son."
                }]}, // End closet room
			  { "names": ["son's room", "brother's room", "son bedroom", "brother bedroom"], "roomId": 6, "neighbors": [9], "unlockItemId": 0, "visited": false, 
                "lockMsg": "The door is sealed shut. It looks like it can be unlocked if you can find the key that fits.", "unlockMsg": "You insert the key, and turn it. The lock clicks, and the door pops open a crack, as if something is trying to escape. You gently pull it the rest of the way open.",
                "roomDesc": "This must be the son's room, a large computer sits on the desk, with posters for old horror movies plastered around the room. You are spooked when you see a figure in the corner of the room, until you realize it is actually a boney skeleton on display. What a strange thing to collect. Behind you is the parent's closet, to your right is the demolished doorway. It must have been a very powerful curse that accomplished this.", 
                "interactables": [ { "names": ["magic skull", "old skull", "skull", "shkull", "magic head"], "take": true, "itemId": 3,
                                    "description": "Suddenly you notice the empty eye sockets of the skeleton's skull start to light up an eerie green. The jaw creaks open, and from it, you hear a strange voice whisper, Shine me by the passage, and I will reveal the way. While this magical skull is very creepy, it could also come in handy if you are to continue." }
			    ]}, // End brother's room
			  { "names": ["daughter's room", "sister's room", "daughter room", "sister room", "daughter's bedroom", "sisters bedroom"], "roomId": 7, "neighbors": [8,4], "unlockItemId": -1, "visited": false,
                "roomDesc": "The daughter's room is unusually dark, even for the mansion. You see a framed portrait of Leonardo DeCaprio by the bed, and a big vat of protein powder on top of the wardrobe. Her diary sits on her desk, her name is on the cover in bold, Gwen Goings. This seems like a young woman of many interests. Perhaps one of them is the occult... There is also a suspiciously empty space in the cluttered room, if only you had some kind of light to shine on it.", 
                "interactables": [{ "names": ["bookshelf", "empty bookshelf", "shelf", "pook shelf", "books"], "take": false,
                                    "description": "There is a fairly large bookshelf by the wall. It seems to be well organized, but there is a noticeably empty space on the end, far too large to be the diary on the desk. What book is missing?."
                }]}, // End daughter's room
			  { "names": ["secret tunnel", "tunnel", "hidden tunnel", "secret passage", "passage"], "roomId": 8, "neighbors": [7, 10], "unlockItemId": 0, "visited": false, 
                "lockMsg": "In the dark of the room, it's hard to tell, but you feel like there is something here, if only you had some way to reveal it.", "unlockMsg": "You shine the glowing green skull on the dark wall, and see a shimmering doorway revealed before you. Who knows where this secret passage could lead?",
                "roomDesc": "This tunnel is extremely dark and strange, if it weren't for the skull you were holding, you wouldn't be able to see anything in front of you. It is extrememly cold and damp, and you appear to be descending downwards. At the end of the passage, you see what looks like the servant's quarters. Behind you is only the daughter's room.", 
                "interactables": [ { "names": ["graffiti", "strange graffiti", "writing", ], "take": true, "itemId": 3,
                                    "description": "Strange writing covers the hallway. You can barely make it out from the green light of the skull, but it seems to be an ancient language, possibly gaelic. From you're experience, it looks like the source of the curse. It seems the only way to lift it is to reveal the one who placed the curse, and banish them from ever returning. But who could it be?" }
				]}, // End secret tunnel room
			  { "names": ["servant's quarters", "servant's room", "maid's room", "butler's room", "servan't bedroom"], "roomId": 8, "neighbors": [7,10], "unlockItemId": -1, "visited": false,
                "roomDesc": "This is the servant's quarters, where the butler and maid stay while they work for the Goings. As you recall, it was seperated from the Mansion, off in a little building to the side of the estate. Just how far did that tunnel take you? The bed's are plain and ordinary, with the everything in the room being functional and neat, despite the decrepit state of everything due to the curse. There is a kennel room to your right, where the dog must've stayed. Perhaps that's the way out?", 
                "interactables": [{ "names": ["strange book", "magic book", "tomb", "magic tomb", "big book"], "take": false,
                                    "description": "A book lies by the maid's bed, it is huge. The writing on the cover looks occult, it has strange markings that signal danger. You peer through the pages and notice a bookmark on a specific curse, one you recognize from the grafitti on the wall. This is the magic tomb that was used to curse the mansion! But who did it belong to?"
                }]}, // End servant's room
			  { "names": ["dog kennel", "kennels", "kennel", "dog room", "dog's room"], "roomId": 10, "neighbors": [8,13], "unlockItemId": -1, "visited": false,
                "roomDesc": "The dog kennels. Many Goings dogs have been raised and bred here over the generations, but eventually they were closed, and the last dog was taken as the family pet. It seems he was  very fond of the family, because even though he passed away, he still haunts the grounds she stayed at. And currently, her ghostly spectre is growling at you and blocking the door to leave. In front of you is the blocked exit, behind you the servant quarters.", 
                "interactables": [{ "names": ["dog", "ghost", "ghost dog", "dog ghost", "pet"], "take": false,
                                    "description": "You're not sure when the family dog passed away, but floating in front of you she looks as alive as ever, despite the fact that you can see through her, and her drool is ectoplasm. She may be small, but you can tell she means business by the way she bears her fangs, you'd rather not pick a fight with this fierce and loyal pup."
                }]}, // End kennel room
			  { "names": ["mansion exit", "the exit", "exit", "final door"], "roomId": 13, "neighbors": [10], "unlockItemId": 0, "visited": false, 
                "lockMsg": "The door is blocked by a ferocious little ghost dog. If only you had some way of showing it you were friendly...", "unlockMsg": "You squeak the duck once and watch the dog's eyes light up. It stops growling, and starts panting, eyes on the chew toy. You place it on the floor, and watch the dog zoom over, and start gnawing on it's old plush friend. You gently pet the dog before you realize your hand goes through it, but the dog seems to get the message, and barks happily. You open the door and step out.",
                "roomDesc": "You leave the small house adjoining the mansion, and march up the grounds to the gates. Waiting for you is the entire Goings family, as well as many concerned citizens of Kingstown. They all wait patiently for you to explain who placed the curse, and what needs to be done.", 
                "interactables": []}			
]; // End rooms and interactactables

// this is used for keep track of visted nodes when we test for loops in the tree
var curRoom = rooms[0];

// These are messages that Alexa says to the user during conversation //

// This is the intial welcome message
var welcomeMsg = "Welcome to the Haunted Mansion Game! If you are unsure what to do in the game, just say help to hear a list of commands. Say start to begin!";

// this is the message that is repeated if Alexa does not hear/understand the reponse to the welcome message
var promptToStartMessage = "If you would like to begin the haunted mansion, say start. Otherwise say exit.";

// this message is played when the user desires to restart the game
var restartMsg = "Ok, we will restart the story.";

// this is the help message during the setup at the beginning of the game
var helpMessage = "To get a description of the room, say describe room. You can enter new rooms by saying enter and the room name. You can inspect items in the room by saying inspect item name.";

// Alexa didn't understand the intent during the game
var unhandledMsg = "I couldn't catch that. If you need a list of commands, say help."

// This is the goodbye message when the user has asked to quit the game
var goodbyeMessage = "Ok, see you next time!";

// Help message when user is accusing who they think did it
var accuseHelpMsg = "It's time to use what you learned and accuse who you think did it. To accuse someone, say: accuse and then the person you think did it. To hear the names of the suspects, say list names.";


// MANSION MESSAGES
var startMansionMsg = "In your long history as an exorcist, you have never seen such a haunted mansion. Formely the home of the wealthy Goings family, the estate has fallen into disrepair after it was mysteriously cursed. Any who has come near it has suffered a tragic demise, leading the residents of Kingstown to enlist your professional help. You step through the solid oak door, into the dimly lit main entrance of the house. To your right is the library, to your left is the dining room. In front of you is the grand staircase, which has a large hole in it, barring you from climbing further. What would you like to do?";

var rptMansionStart = "On your left is the dining room, to your right is the library. Directly ahead of you is the grand staircase, but it is in poor shape. Maybe you should look around a bit?";

var itemPickupMessage = "You picked up the ";

var noItemMessage = "There is no such item here.";

var noBackpackMessage = "If you would like to use an item, please specify an item in your backpack. To hear what's in your bag, say whats in my bag?";

var suspectNames = "The names you can accuse are: the father, the mother, the son, the daughter, the maid, the butler, and the dog.";

// the first node that we will use
var APP_ID = "amzn1.ask.skill.2a42ee53-618f-4795-b5ed-0336250c007b";
// --------------- Handlers -----------------------


// Called when the session starts.
exports.handler = function (event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(newSessionHandler, startGameHandlers, askQuestionHandlers, accuseHandlers);
    alexa.execute();
};

// set state to start up and  welcome the user
var newSessionHandler = {
  'LaunchRequest': function () {
    this.handler.state = states.STARTMODE;
    this.emit(':ask', welcomeMsg, welcomeMsg);
  },'AMAZON.HelpIntent': function () {
    this.handler.state = states.STARTMODE;
    this.emit(':ask', helpMessage, helpMessage);
  },'Unhandled': function () {
    this.handler.state = states.STARTMODE;
    this.emit(':ask', promptToStartMessage, promptToStartMessage);
  }
};

// --------------- Functions that control the skill's behavior -----------------------

// Called at the start of the game, picks and asks first question for the user
var startGameHandlers = Alexa.CreateStateHandler(states.STARTMODE, {
    // User wants to start the mansion
    'StartMansionIntent': function () {
        // set state to asking questions
        this.handler.state = states.ASKMODE;

        // start in first room
        curRoom = rooms[0];

        // Reset all data in the game
        helper.resetGame();

        // Give story introduction
        this.emit(':ask', startMansionMsg, rptMansionStart);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'Unhandled': function () {
        this.emit(':ask', promptToStartMessage, promptToStartMessage);
    }
});


// user will have been asked a question when this intent is called. We want to look at their yes/no
// response and then ask another question. If we have asked more than the requested number of questions Alexa will
// make a choice, inform the user and then ask if they want to play again
var askQuestionHandlers = Alexa.CreateStateHandler(states.ASKMODE, {
    // User requests to pick up an item
    'PickUpIntent': function () {
        // Get name of item
        var itemName = this.event.request.intent.slots.item.value;
        // Get message for Alexa to read to player
        var msg = helper.inspectItem(itemName);
        this.emit(':ask', msg, msg);
    },
    'RepeatRoomDescription': function () {
        helper.repeatRoomDescription(this);
    },
    'EnterRoomIntent': function () {
        var roomName = this.event.request.intent.slots.roomName.value;

        helper.print("Reported room name: " + roomName);

        helper.enterRoom(this, roomName);
    },
    'ExitRoomIntent' : function () {
        // If it is the main entrance, cannot leave
        if (curRoom.roomId == 0) {
            var msg = "You can't leave the mansion before you have found the way out!";
            this.emit(':ask', msg, msg);
        } else {
            // Go to first listed neighbor of current room (always the preceding room)
            helper.enterRoom(this, rooms[curRoom.neighbors[0]].names[0]);
        }
    },
    'UseItemIntent' : function () {
        // Get requested item from backpack
        var itemName = this.event.request.intent.slots.item.value;
        var item = helper.getItem(itemName);
        if (item == null) {
            this.emit(':ask', noBackpackMessage, noBackpackMessage);
        } else {
            // Default message is the user doesn't have the item yet
            var msg = "You do not have any item called " + itemName;
            // If item is in player's bag
            if (item.found === true) {
                msg = "This item has no use here";

                for (var i = 0; i < curRoom.neighbors.length; i++) {

                    // Unlock neighboring room if it is unlocked by item
                    if (curRoom.neighbors[i] == item.useRoom) {
                        rooms[curRoom.neighbors[i]].visited = true;
                        msg = item.useDesc;
                        break;
                    }
                }
            } 
            this.emit(':ask', msg, msg);
        }
    },
    'CheckBagIntent': function () {
        var msg = "In your bag, you find:";
        var itemCount = 0;

        // Add item names to list if they have been found
        for (var i = 0; i < items.length; i++) {
            if (items[i].found === true) {
                msg = msg + " a " + items[i].names[0] + ",";
                itemCount++;
            }
        }
        // If user has no items, change message
        if (itemCount == 0) {
            msg = "You have no items in your bag yet";
        }

        this.emit(':ask', msg, msg);
    },
    'AMAZON.HelpIntent': function () {
        this.emit(':ask', helpMessage, helpMessage);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StartOverIntent': function () {
        // reset the game state to start mode
        this.handler.state = states.STARTMODE;
        this.emit(':ask', welcomeMsg, welcomeMsg);
    },
    'Unhandled': function () {
        this.emit(':ask', unhandledMsg, unhandledMsg);
    }
});

// user has heard the final choice and has been asked if they want to hear the description or to play again
var accuseHandlers = Alexa.CreateStateHandler(states.ACCUSEMODE, {

    'AccuseIntent': function () {
        // Get name of accused and corresponding story text
        var accused = this.event.request.intent.slots.accused.value;
        helper.accuse(this, accused);
    },
    'SuspectNameIntent': function() {
        this.emit(':ask', suspectNames, suspectNames);
    },
    'AMAZON.HelpIntent': function () {
        this.emit(':ask', accuseHelpMsg, accuseHelpMsg);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StartOverIntent': function () {
        // reset the game state to start mode
        this.handler.state = states.STARTMODE;
        this.emit(':ask', welcomeMsg, rptWelcome);
    },
    'Unhandled': function () {
        this.emit(':ask', accuseHelpMsg, accuseHelpMsg);
    }
});

// --------------- Helper Functions  -----------------------

var helper = {

    // Return the room, else return null
    getRoom: function (roomName) {
        if (roomName == null) {
            return roomId;
        } 

        // See if name exists in name lists of adjoining rooms
        for (var i = 0; i < curRoom.neighbors.length; i++) {

            // Get neighbor
            var neighbor = rooms[curRoom.neighbors[i]];

            // If roomName is one of the names in the list, return that room
            for(var j = 0; j < neighbor.names.length; j++) {
                if (roomName == neighbor.names[j]) {
                    return neighbor;
                }
            }
        }
        return null; // Room not a neighbor
    },

    // Enters the next room the user wants to enter
    enterRoom: function (context, roomName) {

        var room = helper.getRoom(roomName);
        var msg = "If you would like to enter a room, please say enter followed by the name of an adjoining room.";

        if (room != null) {

            var lockRoom = false;

            // If room is locked and needs an item to open
            if (room.unlockItemId != -1 && room.visited === false) {

                lockRoom = true;

                // If user has item to unlock room, unlock it
                if (items[room.unlockItemId].found === true) {
                    room.visited = true;
                    curRoom = room;
                }
            } 

            // If room was locked
            if (lockRoom) {
                // If user just unlocked it
                if (room.visited) {
                    msg = room.unlockMsg + " " + curRoom.names[0] + ": " +room.roomDesc + helper.getAdjacentRooms() + helper.getInteractables();
                    context.emit(":ask", msg, msg);
                } 
                // If user did not have proper item to unlock room
                else {
                    context.emit(":ask", room.lockMsg, room.lockMsg);
                }
            } else {
                // Enter room and echo description
                room.visited = true;
                curRoom = room;

                msg = curRoom.names[0] + ": " + room.roomDesc + helper.getAdjacentRooms() + helper.getInteractables();

                if (room.names[0] == "mansion exit") {
                    context.handler.state = states.ACCUSEMODE;
                    msg = room.roomDesc + accuseHelpMsg;
                }

                context.emit(':ask', msg, msg);
            }
        } 
        // User didn't provide a/valid room name
        else {
            // helper.print("ROOM NOT FOUND!"); // DEBUG
            context.emit(':ask', msg, msg);
        }
    },

    // Enters the next room the user wants to enter
    accuse: function (context, accused) {
        var famNames = ["father", "mother", "son", "boy", "dad", "mom", "dog", "butler", "maid"];
        var sisNames = ["daughter", "sister", "gwen", "girl"]
        var correctAccuse = false;
        var isListedName = false;

        for (var i = 0; i < sisNames.length; i++) {
            if (accused == sisNames[i]) {
                correctAccuse = true;
                break;
            }
        }

        // If they did not guess the sister
        if (!correctAccuse) {

            // See if their guess was valid
            for (var i = 0; i < famNames.length; i++) {
                if (accused == famNames[i]) {
                    isListedName = true;
                    break;
                }
            }
        }

        if (correctAccuse) {
            // Win scenario
            context.handler.state = states.STARTMODE;
            var msg = "You point your finger at the daughter who takes a step back. The local sherriff starts to approach her as she mutters an incantation under her breath. Prepared for her, you redirect the spell back at her, turning her into a harmless chicken. As you do, the gloom over the mansion fades. You have lifted the curse! Thank you for playing!";
            context.emit(':tell', msg, msg);
        } else if (isListedName) {
            // Wrong choice scenario
            var msg = "You accuse " + accused + " of foul play in the mansion. The crowd laughs, thinking you are making a joke. One of the family members smirks, while the rest stare daggers at you, the father calling you totally worthless. You should think hard, and try again.";
            context.emit(':ask', msg, msg);
        } else {
            var msg = "I'm sorry, " + accused + " is not a valid name to accuse. For the full list of names, please say list names";
            context.emit(':ask', msg, msg);
        }
    },

    // Repeats the description of the current room
    repeatRoomDescription: function (context) {
        var msg = curRoom.names[0] + ": " + curRoom.roomDesc + helper.getAdjacentRooms() + helper.getInteractables();
        context.emit(':ask', msg, msg);
    },

    // Returns string of all neighbor names
    getAdjacentRooms: function() {
        var roomNames = " The adjoining rooms are: ";
        var thisRoom = "";

        // Only one room
        if (curRoom.neighbors.length == 1) {
            return " The adjoining room is the " + rooms[curRoom.neighbors[0]].names[0] + ". ";
        }

        // Add all neighbor room names to string roomNames
        for (var i = 0; i < curRoom.neighbors.length; i++) {

            // Get neighbor room name
            thisRoom = rooms[curRoom.neighbors[i]].names[0];

            // Correct list grammar using "and" if the room is the last in the list
            if (i != curRoom.neighbors.length - 1) {
                roomNames = roomNames + " the " + thisRoom + ",";
            } else {
                roomNames = roomNames + " and the " + thisRoom + ". ";
            }
        }

        return roomNames;
    },

    // Returns string of all neighbor names
    getInteractables: function() {
        var itemNames = "You see the following items: ";

        // Return nothing if there are no items.
        if (curRoom.interactables.length == 0) {
            return "";
        }

        // Only one item
        if (curRoom.interactables.length == 1) {
            if (curRoom.interactables[0].take == true && items[curRoom.interactables[0].itemId] == false) {
                return "In the room you see the following item: " + curRoom.interactables[0].names[0] + ".";
            } else {
                return "";
            }
        }

        // Add all item names to string itemNames
        for (var i = 0; i < curRoom.interactables.length; i++) {

            // If not last room, add comma
            if (i != curRoom.interactables.length - 1) {
                itemNames = itemNames + curRoom.interactables[i].names[0] + ", ";
            } else {
                itemNames = itemNames + "and " + curRoom.interactables[i].names[0] + ".";
            }
        }

        return itemNames;
    },

    // Returns the item searched for, or null if nothing was found
    getItem: function(itemName) {
        for (var i = 0; i < items.length; i++) {
            if (items[i].names[0] == itemName) {
                return items[i];
            }
        }
        // Item not found
        return null;
    },

    // Finds item, picks up if available. Returns message read to player
    inspectItem: function (itemName) {

        for (var i = 0; i < curRoom.interactables.length; i++) {

            // If itemName matches a names of the item, inspect it
            for (var j = 0; j < curRoom.interactables[i].names.length; j++) {

                // Interactable found
                if (curRoom.interactables[i].names[j] == itemName) {

                    // If interactable is a pickup item
                    if (curRoom.interactables[i].take === true) {

                        // Get item
                        var item = helper.getItem(curRoom.interactables[i].names[0]);

                        // Item doesn't exist
                        if (item == null) {
                            return noItemMessage;
                        }
                        // If item hasn't been picked up yet
                        else if (item.found === false) {
                            item.found = true;
                            return curRoom.interactables[i].description;
                        } 
                        // User has already picked up the item
                        else {
                            return "You have already picked up the " + itemName + ".";
                        }
                    } 
                    // If interactable is just observation
                    else {
                        return curRoom.interactables[i].description;
                    }
                }
            }
        }
        // Default message if nothing is found
        return "If you would like to inspect something, you must also specify the name of an item in the room.";
    },

    // Resets all data for a new game
    resetGame: function () {

        // Reset found items
        for (var i = 0; i < items.length; i++) {
            items[i].found = false;
        }

        // Reset all rooms
        for (var i = 0; i < rooms.length; i++) {
        
            // Unvisit all rooms
            rooms[i].visited = false;
            
            // Set all items to not taken
            for (var j = 0; j < rooms[i].interactables.length; j++) {
                if (rooms[i].interactables[j].take == true) {
                    rooms[i].interactables[j].taken = false;
                }
            }
        }
    },

    print: function (text) {
        console.log("\n\n|>|>|> " + text + "\n\n");
    }
};


